function X = mid(X);

X.basis = mid(X.basis);
